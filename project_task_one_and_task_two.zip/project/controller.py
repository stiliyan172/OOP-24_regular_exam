from project.player import Player


class Controller:
    def __init__(self):
        self.players = []
        self.supplies = []

    def add_player(self, *players: Player):
        players_names = []
        for player in players:
            if player in self.players:
                continue
            players_names.append(player.name)
            self.players.append(player)
        return f'Successfully added: {", ".join(players_names)}'

    def add_supply(self, *supplies):
        for supply in list(supplies):
            self.supplies.append(supply)

    def sustain(self, player_name: str, sustenance_type: str):
        if sustenance_type not in ["Food", "Drink"]:
            return
        for player in self.players:
            if player_name == player.name:
                current_player = player
        if not any(player_name == player.name for player in self.players):
            return
        if not current_player.need_sustenance:
            return f"{player_name} have enough stamina."
        if sustenance_type == "Food":
            if not any(supply for supply in self.supplies if supply.type_of_supply == "Food"):
                return f"There are no food supplies left!"
            last_supply = [supply for supply in self.supplies if supply.type_of_supply == "Food"][-1]
            if current_player.stamina + last_supply.energy > 100:
                last_supply.energy = 100 - current_player.stamina
            current_player.stamina += last_supply.energy
            return f"{player_name} sustained successfully with {last_supply.name}."
        elif sustenance_type == "Drink":
            if not any(supply for supply in self.supplies if supply.type_of_supply == "Drink"):
                return f"There are no drink supplies left!"
            last_supply = [supply for supply in self.supplies if supply.type_of_supply == "Drink"][-1]
            if current_player.stamina + last_supply.energy > 100:
                last_supply.energy = 100 - current_player.stamina
            current_player.stamina += last_supply.energy
            return f"{player_name} sustained successfully with {last_supply.name}."

    def duel(self, first_player_name: str, second_player_name: str):
        for player in self.players:
            if player.name == first_player_name:
                first_player = player
            if player.name == second_player_name:
                second_player = player
        if first_player.stamina == 0:
            return f"Player {first_player_name} does not have enough stamina."
        elif second_player.stamina == 0:
            return f"Player {second_player_name} does not have enough stamina."
        first_attacker = first_player if first_player.stamina < second_player.stamina else second_player
        the_other_attacker = first_player if first_player.stamina > second_player.stamina else second_player
        counter = 0
        while first_player.stamina > 0 and second_player.stamina > 0:
            if counter % 2 == 0:
                the_other_attacker.stamina -= first_attacker.stamina / 2
        if first_player.stamina == 0:
            return f"Winner: {second_player.name}"
        elif second_player.stamina == 0:
            return f"Winner: {first_player.name}"


    def next_day(self):
        for player in self.players:
            player.stamina -= player.age * 2
            if player.stamina < 0:
                player.stamina = 0
            player.sustain("Food")
            player.sustain("Drink")

    def __str__(self):
        result = []
        for player in self.players:
            result.append(f"Player: {player.name}, {player.age}, {player.stamina}, {player.need_sustenance} \n")
        for supply in self.supplies:
            result.append(f'{supply.type_of_supply}: {supply.name}, {supply.energy} \n')

        return "".join(result)


